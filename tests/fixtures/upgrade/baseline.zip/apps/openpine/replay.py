"""Composition and CLI for finite, isolated offline event replay."""

import argparse
import os
import subprocess
import sys
import tempfile
import time
import itertools
import apsw
from dataclasses import asdict
from pathlib import Path

from packages.contracts import HISTORICAL_PROFILE_ID
from packages.contracts.contexts import MarketContext
from packages.contracts.trading import BrokerSettings
from packages.contracts.realtime import policy
from packages.contracts.realtime import PROFILE
from packages.contracts.live import event_policy
from packages.contracts.wire import atomic_json, canonical, loads, read_json
from packages.execution.artifacts import import_program, export_program
from packages.execution.realtime import ReplayEngine
from packages.execution.resources import resident_bytes
from packages.execution.session import Session
from packages.storage.lease import Lease
from packages.storage.replay import ReplayRepository
from packages.storage.results import series_rows
from packages.storage.trades import event_rows

ROOT = Path(__file__).resolve().parents[2]


class EmptySink:
    def __init__(self):self.cleanups=[]
    def enable_simulation(self,**kwargs):pass
    def trade_history_factory(self):
        from packages.storage.trade_index import TradeIndex
        return TradeIndex()


class Replays:
    def __init__(self, manager):
        self.manager = manager
        self.repository = ReplayRepository(manager.db, manager.objects)

    def create(self, payload):
        names = {'input_ref','contexts','primary_id','broker_settings','timeout_seconds'}
        if type(payload) is not dict or not names<=payload.keys()<=names|{'event_profile','broker_profile','calculation_profile','cycle_settings','inputs','settings','environments','lower_tf'} or 'inputs' in payload and 'settings' in payload: raise ValueError('Invalid replay creation fields.')
        if (type(payload['contexts']) is not list or not 1 <= len(payload['contexts']) <= 8
                or type(payload['timeout_seconds']) not in (int,float) or not 0 < payload['timeout_seconds'] <= 3600):
            raise ValueError('Invalid replay contexts/timeout.')
        with self.manager.limiter.slot('prepare'):
            content = self.manager.objects.get(payload['input_ref'])
            session = Session(profile_id=HISTORICAL_PROFILE_ID,memory_mb=self.manager.policy.memory_mb_per_worker)
            if 'artifact_ref' in content:
                program = import_program(self.manager.objects.get(content['artifact_ref']))
            elif content.keys() == {'source','source_name'}:
                program = session.compile(content['source'],content['source_name'])
            else: raise ValueError('Replay input needs source or compiled IR.')
            contexts = tuple(MarketContext.from_payload(c) for c in payload['contexts'])
            settings = BrokerSettings.from_payload(payload['broker_settings']) if payload['broker_settings'] is not None else None
            profile=payload.get('event_profile',PROFILE)
            from packages.contracts.inputs import admitted_settings,settings_for
            execution_settings=admitted_settings(program,payload['settings']) if 'settings' in payload else settings_for(program,payload.get('inputs'))
            engine = ReplayEngine(session, program, contexts, payload['primary_id'], EmptySink(), broker_settings=settings,profile=profile,settings=execution_settings,environments=payload.get('environments'),broker_profile=payload.get('broker_profile'),calculation_profile=payload.get('calculation_profile'),cycle_settings=payload.get('cycle_settings'),lower_tf=payload.get('lower_tf'))
            normalized={k:v for k,v in payload.items() if k not in ('inputs','settings')}
            if engine.has_environment:normalized['environments']=engine.environment_inputs
            if engine.broker_profile:normalized['broker_profile']=engine.broker_profile
            if engine.calculation_profile:normalized['calculation_profile']=engine.calculation_profile
            if engine.cycle_mode:normalized['cycle_settings']=engine.cycle_settings
            if engine.lower_config:normalized['lower_tf']=engine.lower_config
            config = {'schema_version':'openpine.replay-config.7' if engine.prepared_graph else 'openpine.replay-config.6' if engine.lower_config else 'openpine.replay-config.5' if engine.cycle_mode else 'openpine.replay-config.4' if engine.calculation_profile else 'openpine.replay-config.3' if engine.has_environment else 'openpine.replay-config.2' if execution_settings else 'openpine.replay-config.1', **normalized,
                **({'settings':execution_settings} if execution_settings else {}),
                'artifact_ref':self.manager.objects.put(export_program(program)), 'identity':engine.identity,
                'event_profile':profile,'policy':engine.qualification(),
                'memory_mb':self.manager.policy.memory_mb_per_worker, 'threads':self.manager.policy.threads_per_worker,
                'heartbeat_timeout':self.manager.policy.heartbeat_timeout,
                'object_quota_bytes':self.manager.objects.quota_bytes}
            if engine.simulation:engine.simulation.close()
            identifier = self.repository.create(config)
            return self.repository.status(identifier)

    def append(self, identifier, events):
        with self.manager.limiter.slot('prepare'):
            self.repository.append(identifier, events)
            with tempfile.TemporaryDirectory(prefix='replay-tape-',dir=self.manager.directory) as temporary:
                self.repository.archive(identifier,temporary)
            return self.status(identifier)
    def status(self, identifier):
        state=self.repository.status(identifier)
        waiting=self.manager.worker_waiting(identifier)
        if waiting:state['waiting']=waiting
        return state

    def pin_lower_warmup(self,identifier,warmup):
        """Freeze discovered snapshot counts before any event can be accepted."""
        self.repository.row(identifier)
        with self.manager.limiter.slot('prepare'),Lease(self.manager.directory/('.replay-'+identifier+'.lock')):
            config=self.repository.config(identifier)
            if not config.get('lower_tf'):return
            if config['lower_tf']['warmup']==warmup:return
            session=Session(profile_id=HISTORICAL_PROFILE_ID,memory_mb=config['memory_mb']);program=import_program(self.manager.objects.get(config['artifact_ref']))
            selected={**config['lower_tf'],'warmup':warmup}
            engine=ReplayEngine(session,program,tuple(MarketContext.from_payload(c) for c in config['contexts']),config['primary_id'],EmptySink(),
                broker_settings=BrokerSettings.from_payload(config['broker_settings']) if config['broker_settings'] else None,
                profile=config['event_profile'],settings=config.get('settings'),environments=config.get('environments'),
                broker_profile=config.get('broker_profile'),calculation_profile=config.get('calculation_profile'),cycle_settings=config.get('cycle_settings'),lower_tf=selected)
            try:self.repository.repin_empty(identifier,{**config,'lower_tf':engine.lower_config,'identity':engine.identity,'policy':engine.qualification()})
            finally:
                if engine.simulation:engine.simulation.close()

    def advance(self, identifier, *, max_events=10000000, checkpoint_every=10000, cancelled=lambda:False):
        if (type(max_events) is not int or not 1 <= max_events <= 10000000
                or type(checkpoint_every) is not int or not 1 <= checkpoint_every <= 1000000):
            raise ValueError('Invalid replay execution/checkpoint limit.')
        config = self.repository.config(identifier);started=time.monotonic();peak=0;native_metrics={}
        with self.manager.reserve_worker(config['memory_mb'], config['threads'],request_id='replay:'+identifier):
            # A per-replay lease prevents two attempts from publishing the same
            # output prefix. The coordinator lease keeps GC away from attempts.
            with Lease(self.manager.directory/('.replay-'+identifier+'.lock')):
                with tempfile.TemporaryDirectory(prefix='replay-attempt-', dir=self.manager.directory) as temporary:
                    path = Path(temporary)
                    args = [sys.executable,'-X','utf8','-c',
                        "import runpy,sys;sys.path.insert(0,sys.argv.pop(1));runpy.run_module('apps.replay_worker',run_name='__main__')",
                        str(ROOT),'--store',str(self.manager.directory),'--id',identifier,'--attempt',str(path),
                        '--max-events',str(max_events),'--checkpoint-every',str(checkpoint_every),'--parent-pid',str(os.getpid())]
                    with (path/'worker.log').open('wb') as log:
                        from packages.execution.supervisor import Supervisor,WorkerFault
                        supervisor=self.manager.start_worker(args,path,log,threads=config['threads'],timeout=config['timeout_seconds'],
                            heartbeat_timeout=config['heartbeat_timeout'],memory_mb=config['memory_mb'])
                        process=supervisor.process
                        try:
                            while process.poll() is None:
                                try:supervisor.poll(cancelled=cancelled())
                                except WorkerFault as error:
                                    if error.code=='CANCELLED':raise InterruptedError(str(error)) from error
                                    raise
                                peak=supervisor.peak
                                time.sleep(.05)
                            if process.returncode:
                                error = read_json(path/'error.json') if (path/'error.json').exists() else {'message':f'Replay worker exited with {process.returncode}.'}
                                if error.get('code')=='DISK_WAIT':self.manager.defer_worker('replay:'+identifier,error['admission'])
                                raise ValueError(error['message'])
                            if (path/'metrics.json').exists():native_metrics=read_json(path/'metrics.json',max_bytes=4096)
                        finally:
                            self.manager.stop_worker(supervisor)
        self.last_metrics={'wall_seconds':time.monotonic()-started,'peak_rss_sampled_bytes':peak,'worker_launches':1,**native_metrics}
        return self.status(identifier)

    def advance_many(self,identifiers,*,max_events=1000,checkpoint_every=1000,cancelled=lambda identifier:False):
        from apps.openpine.replay_batch import advance_many
        return advance_many(self,identifiers,max_events=max_events,checkpoint_every=checkpoint_every,cancelled=cancelled)

    def view(self, identifier, action, start=0, limit=2000):
        if type(start) is not int or start < 0 or type(limit) is not int or not 1 <= limit <= 5000: raise ValueError('Invalid replay range.')
        state = self.status(identifier)
        if action == 'chart':
            end = min(state['confirmed_bars'],start+max(1,min(limit,5000//max(1,len(state['outputs'])))))
            rows = list(itertools.islice(series_rows(self.manager.objects, {'observation_count':state['confirmed_bars'],'series':state['series']},start,end),5000))
            return {'rows':rows,'preview':state['preview'],'total':state['confirmed_bars'],'next':end}
        if action != 'ledger': raise ValueError('Unknown replay view.')
        journal = (state['simulation'] or {}).get('journal',{'records':0,'parts':[]})
        events = list(event_rows(self.manager.objects,journal,start,limit))
        return {'events':events,'total':journal['records'],'next':start+len(events)}


def main(argv=None):
    from apps.openpine.bootstrap import local_manager
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=('create','append','advance','status','chart','ledger'))
    parser.add_argument('--state-dir',type=Path,default=Path('.runtime/jobs'))
    parser.add_argument('--id')
    parser.add_argument('--source',type=Path)
    parser.add_argument('--artifact',type=Path)
    parser.add_argument('--contexts',type=Path,help='JSON with contexts, primary_id and optional broker_settings')
    parser.add_argument('--inputs',type=Path,help='JSON input overrides for create only')
    parser.add_argument('--events',type=Path,help='streamed market-event NDJSON')
    parser.add_argument('--timeout',type=float,default=60)
    parser.add_argument('--broker-profile',choices=('observed',),help='opt in to sampled-price paper orders and protection')
    parser.add_argument('--calculation-profile',choices=('observed','cycle'),help='calculate on received primary updates; source header is authoritative')
    parser.add_argument('--calc-on-order-fills',action=argparse.BooleanOptionalAction,default=None)
    parser.add_argument('--process-orders-on-close',action=argparse.BooleanOptionalAction,default=None)
    parser.add_argument('--max-events',type=int,default=10000000)
    parser.add_argument('--checkpoint-every',type=int,default=10000)
    parser.add_argument('--start',type=int,default=0)
    parser.add_argument('--limit',type=int,default=2000)
    parser.add_argument('--output',type=Path)
    args = parser.parse_args(argv)
    if args.output and args.output.resolve() in {p.resolve() for p in (args.source,args.artifact,args.contexts,args.events) if p}: parser.error('Output must not overwrite an input.')
    if args.command == 'create':
        if bool(args.source) == bool(args.artifact) or not args.contexts or args.id: parser.error('Create requires one --source/--artifact and --contexts.')
    elif not args.id or args.source or args.artifact or args.contexts or args.inputs or args.broker_profile or args.calculation_profile or args.calc_on_order_fills is not None or args.process_orders_on_close is not None: parser.error('Existing replay commands require --id and use their pinned configuration.')
    if (args.command == 'append') != bool(args.events): parser.error('Append requires --events; other commands do not accept it.')
    try:
        with local_manager(args.state_dir) as manager:
            service = Replays(manager)
            if args.command == 'create':
                if args.source:
                    with args.source.open('rb') as stream: text=stream.read(65537).decode('utf-8')
                    content={'source':text,'source_name':args.source.name}
                else:
                    from packages.execution.artifacts import read_program
                    content={'artifact':export_program(read_program(args.artifact))}
                inputs=read_json(args.contexts)
                if type(inputs) is not dict or not {'contexts','primary_id'}<=inputs.keys()<={'contexts','primary_id','broker_settings','environments','event_profile','broker_profile','calculation_profile','cycle_settings','lower_tf'}: raise ValueError('Invalid replay context file.')
                value=service.create({'input_ref':manager.freeze_input(content),**inputs,
                    'broker_settings':inputs.get('broker_settings'),'timeout_seconds':args.timeout,
                    **({'broker_profile':'openpine.observed-broker.1'} if args.broker_profile else {}),
                    **({'calculation_profile':'openpine.observed-calculation.1' if args.calculation_profile=='observed' else 'openpine.strategy-cycle.1'} if args.calculation_profile else {}),
                    **({'cycle_settings':{k:v for k,v in {'calc_on_order_fills':args.calc_on_order_fills,'process_orders_on_close':args.process_orders_on_close}.items() if v is not None}} if args.calc_on_order_fills is not None or args.process_orders_on_close is not None else {}),
                    **({'inputs':read_json(args.inputs)} if args.inputs else {})})
            elif args.command == 'append':
                batch=[]
                with args.events.open('rb') as stream:
                    while raw := stream.readline(65537):
                        batch.append(loads(raw,max_bytes=65536))
                        if len(batch)==1000: service.append(args.id,batch);batch=[]
                if batch: service.append(args.id,batch)
                value=service.status(args.id)
            elif args.command == 'advance': value=service.advance(args.id,max_events=args.max_events,checkpoint_every=args.checkpoint_every)
            elif args.command == 'status': value=service.status(args.id)
            else: value=service.view(args.id,args.command,args.start,args.limit)
        code=0
    except (ValueError,OSError,apsw.Error) as error:
        value={'status':'rejected','diagnostics':[{'code':'REPLAY_INVALID','message':str(error)}]};code=2
    if args.output: atomic_json(args.output,value)
    else: sys.stdout.buffer.write(canonical(value)+b'\n')
    return code
