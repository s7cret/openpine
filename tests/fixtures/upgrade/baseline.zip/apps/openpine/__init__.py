"""OpenPine CLI application."""
